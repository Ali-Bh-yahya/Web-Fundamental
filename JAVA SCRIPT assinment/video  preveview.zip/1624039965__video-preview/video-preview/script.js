console.log("page loaded...");

function start_video(element) {
  element.play();
}
function close_video(element) {
  element.pause();
}
